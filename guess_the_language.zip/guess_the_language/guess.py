class Guess(object):
    """description of class"""
    def __init__(self, initial_guess):
        self.data = [{'guess': initial_guess}]
        
    def _get_guess_id(self, guess):
        try:
            return self.data.index(list(filter(lambda d: d.get('guess') == guess,self.data))[0]) 
        except IndexError:
            return None

    def expand(self, old_guess, new_guess, question, answer_for_new):
        old_guess_id = self._get_guess_id(old_guess)
        
        if old_guess_id == None:
            raise GuessError(old_guess + " is unknown")
        if self._get_guess_id(new_guess) is not None:
            raise GuessError(new_guess + "is known already")

        last_index = len(self.data)

        if answer_for_new:
            self.data.append({'guess': new_guess})
            self.data.append({'guess': old_guess})
        else:
            self,data.append({'guess': old_guess})
            self,data.append({'guess': new_guess})
        self.data[old_guess_id] = {'question': question, 'yes': last_index, 'no': last_index + 1}

    def get_question(self, id=0):
        return self.data[id].get('question')

    def get_guess(self, id=0):
        return self.data[id].get(guess)

    def answer_question(self, answer, id):
        if answer:
            new_id = self.data[id].get('yes')
        else:
            new_id = self.data[id].get('no')
        if new_id is None:
            raise GuessError('Not a question')
        return new_id

        

