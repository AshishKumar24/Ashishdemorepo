import mysql.connector



connection_string = { "user": "root",
                     "password": "",
                     "host": "localhost"
    }
class Database(object):
    connection = None
    def __init__(self):
        pass

    @staticmethod
    def initialize():
        Database.connection = mysql.connector.connect(**connection_string)

    @staticmethod
    def execute_query(query=None):
        #cursor = Database.connection.cursor(dictionary=True)
        cursor = Database.connection.cursor()
        if query is None:
            return None
        cursor.execute(query)
        col_list = []
        
        for col_name in cursor.column_names:
            col_list.append({'column': col_name})

        return [col_list,cursor.fetchall()]

    @staticmethod
    def close_connection():
        Database.connection.close()

    @staticmethod
    def convert_json(cursor):
        data_list = []
        for data in cursor.fetchall():
            data_list.append(dict(zip(cursor.column_names, data)))
            
        return {'data': data_list}   

if __name__ == '__main__':
    Database.initialize()
    data = Database.execute_query('select name from tweets.users where followers_count <= 100 limit 10')
    print(data)
    print(type(data))
