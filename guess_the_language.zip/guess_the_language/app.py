"""
This script runs the application using a development server.
It contains the definition of routes and views for the application.
"""

from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_wtf import Form
from wtforms.fields import RadioField, SubmitField, StringField
from guess import Guess
from database import Database
import json

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

#questions = ['Is it compiled?', 'Does it run on VM']
#guesses = ['Java','Python','Scala']
game = Guess('Python')
game.expand('Python','C++','Is it compiled?', True)

# Make the WSGI interface available at the top level so wfastcgi can get it.
wsgi_app = app.wsgi_app


class YesNoQuestionForm(Form):
    answer = RadioField("Your Answer", choices=[('yes', 'Yes'),('no', 'No')])
    submit= SubmitField('Submit')

class LearnForm(Form):
    language = StringField('What Language did you pick?')
    question = StringField('What is the question that differentiates your language?')
    answer = RadioField('What is the answer for your language?', choices=[('yes','Yes'),('no','No')])
    submit= SubmitField('Submit')


@app.route('/')
def index():
    """Renders a sample page."""
    return render_template("index.html")

@app.route('/question/<int:id>', methods=['GET', 'POST'])
def question(id):
    question = game.get_question(int(id))  
    form = YesNoQuestionForm()
    #if request.method == 'POST':
    #    if request.form['answer'] == "Yes":
    if form.validate_on_submit():
        if form.answer.data == 'yes':
            return redirect(url_for('question', id=id+1))
        else:
            return redirect(url_for('index', id=id))
    return render_template("question.html", question= question, form = form)

@app.route('/guess/<int:id>')
def guess(id):
    guess = game.get_guess(id)
    if guess is None:
        return redirect(url_for('index'))

    form = YesNoQuestionForm()
    if form.validate_on_submit():
        if form.answer.data == 'yes':
            return redirect(url_for('index'))
        return redirect(url_for('learn', id=id))

    return render_template("guess.html", guess=guess, form=form)

@app.route('/learn/<int:id>', methods=['Get', 'Post'])
def learn(id):
    guess = game.get_guess(id)
    form = LearnForm()
    if form.validate_on_submit():
        game.expand(guess, form.language.data, form.question.data,
                    form.answer.data == 'yes')
        return redirect(url_for('index'))
    return render_template('learn.html',guess=guess, form=form)

@app.route('/data', methods=['Get'])
@app.route('/data/<string:query>', methods=['Get'])
def fetch_data(query=None):
    if query == None:
        query = "Select * from INFORMATION_SCHEMA.COLUMNS"
  
    Database.initialize()
    data = Database.execute_query(query)
    print(data)
    return jsonify(data)

@app.route('/visual', methods=['Get'])
def visual():
    return render_template('visual.html')


if __name__ == '__main__':
    import os
    HOST = os.environ.get('SERVER_HOST', 'localhost')
    try:
        PORT = int(os.environ.get('SERVER_PORT', '5555'))
    except ValueError:
        PORT = 5555
    app.run(HOST, PORT,debug=True)
