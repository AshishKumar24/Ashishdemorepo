// JavaScript source code

var tableData = null;
var metadata = null;
var colorScale = d3.scaleOrdinal(d3.schemeCategory20c);

function fetch_data() {
    query = document.getElementById('sql').value;
    d3.json('/data/' + query).get(function (error, data) {
        metadata = data[0];
        tableData = data[1];
        vizRadioGroup.attr('disabled', false);
    });
};

function createChart() {
    vizType = $('input[name=vizType]:checked').val();

    if (vizType == 'table') {
        tabulate(tableData, metadata);
    }
    else if (vizType == 'barChart') {
        console.log('Bar Chart');
        d3.select('svg').remove()
        drawBarChart();
    }
    else if (vizType == 'pieChart') {
        console.log('pieChart');
        pieChart()
    }

};

$(document).ready(function () {
    vizRadioGroup = $('input[name=vizType]')
    //vizRadioGroup.on('change', visualize)
    if (tableData == null || metadata == null) {
        vizRadioGroup.attr('disabled', true);
    }
    vizRadioGroup.on('change', visualize)
});


function visualize() {
    vizType = $('input[name=vizType]:checked').val();
    
    if (vizType == 'table') {
        tabulate(tableData, metadata);
    }
    else if (vizType == 'barChart') {
        console.log('Bar Chart');
        d3.select('svg').remove()
        barChart();
    }
    else if (vizType == 'pieChart') {
        console.log('pieChart');
        pieChart()
    }
};

function barChart() {
    console.log(metadata);
    d3.selectAll('table').remove();
    d3.selectAll('svg').remove();
    d3.select('#xAxis').selectAll('option').remove();
    d3.select('#yAxis').selectAll('option').remove();
    var xAxis = d3.select('#xAxis').selectAll('option').data(metadata).enter().append('option').text(function (d) { return d.column });
    var yAxis = d3.select('#yAxis').selectAll('option').data(metadata).enter().append('option').text(function (d) { return d.column });

}

function pieChart() {
    console.log(metadata);
}

function tabulate(tableData, metaData) {
    d3.selectAll('table').remove()
    d3.selectAll('svg').remove()
    var table = d3.select('#visual').append('table').attr('class', 'table table-hover');
    var thead = table.append('thead');
    var tbody = table.append('tbody');

    thead.append('tr')
        .selectAll('th')
        .data(metaData)
        .enter()
        .append('th')
        .text(function (d) { return d.column; })
        .attr('class', 'header');
    
    var rows = tbody.selectAll('tr')
        .data(tableData)
        .enter()
        .append('tr');

    var cells = rows.selectAll('td')
        .data(function (d) {
            return metadata.map(function (column) {
                return { column: column.column, value: d[column.column] }
            });
        })
        .enter()
        .append('td')
        .text(function (d) { return d.value; });
};

function drawBarChart() {
    var xColumn = d3.select('#xAxis').property('value');
    var yColumn = d3.select('#yAxis').property('value');
    console.log(xColumn + " " + yColumn);
    

    var maxLength = d3.max(tableData, function (d) { return d[xColumn].length });
    console.log(maxLength)
    svg = d3.select('#visual').append('svg').attr('width', "960").attr('height', "500");
    var margin = { top: 20, right: 20, bottom: 80, left: 80 },
        width = +svg.attr("width") - margin.left - margin.right ,
        height = +svg.attr("height") - margin.top - margin.bottom - maxLength - 20;
    console.log(height)

    var x = d3.scaleBand().rangeRound([0, width]).padding(0.1),
        y = d3.scaleLinear().rangeRound([height, 0]);

    var g = svg.append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    x.domain(tableData.map(function (d) { return d[xColumn]; }));
    y.domain([0, d3.max(tableData, function (d) { return d[yColumn]; })]);

    g.append("g")
        .attr("class", "axis axis--x")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x))
        .selectAll('text')
        .style("text-anchor", "end")
        .attr("dx", "-.5em")
        .attr("dy", "-.55em")
        .attr("transform", "rotate(-40)");


    g.append("g")
        .attr("class", "axis axis--y")
        .call(d3.axisLeft(y).ticks(10))
        .append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 6)
        .attr("dy", "0.71em")
        .attr("text-anchor", "end")
        .text("Frequency");

    g.selectAll(".bar")
        .data(tableData)
        .enter().append("rect")
        .attr("class", "bar")
        .attr("x", function (d) { return x(d[xColumn]); })
        .attr("y", function (d) { return y(d[yColumn]); })
        .attr("width", x.bandwidth())
        .attr("height", function (d) { return height - y(d[yColumn]); })
        .attr('fill', function (d, i) { return colorScale(i)});
 }